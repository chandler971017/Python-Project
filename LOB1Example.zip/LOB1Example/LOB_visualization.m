%% Data read in
%unzip("LOBSTER_SampleFile_INTC_2012-06-21_5.zip");
% Level 5 data definition (five levels away from the midprice on either side) is contained in two CSV files. Extract the trading date from the message file name.

MSGFileName = "INTC_2012-06-21_34200000_57600000_message_5.csv";   % Message file (description of data)
LOBFileName = "INTC_2012-06-21_34200000_57600000_orderbook_5.csv"; % Data file

[ticker,rem] = strtok(MSGFileName,'_');
date = strtok(rem,'_');
%%
% Data Storage
% Daily data streams accumulate and need to be stored. 
% A datastore is a repository for collections of data that are too big to fit in memory.
% Use tabularTextDatastore to create datastores for the message and data files. 
% Because the files contain data with different formats, create the datastores separately. 
% Ignore generic column headers (for example, VarName1) by setting the 'ReadVariableNames' name-value pair argument to false. 
% Replace the headers with descriptive variable names obtained from LOBSTER_SampleFiles_ReadMe.txt. 
% Set the 'ReadSize' name-value pair argument to 'file' to allow similarly formatted files to be appended to existing datastores at the end of each trading day.
DSMSG = tabularTextDatastore(MSGFileName,'ReadVariableNames',false,'ReadSize','file');
DSMSG.VariableNames = ["Time","Type","OrderID","Size","Price","Direction"];

DSLOB = tabularTextDatastore(LOBFileName,'ReadVariableNames',false,'ReadSize','file');
DSLOB.VariableNames = ["AskPrice1","AskSize1","BidPrice1","BidSize1",...
                       "AskPrice2","AskSize2","BidPrice2","BidSize2",...
                       "AskPrice3","AskSize3","BidPrice3","BidSize3",...
                       "AskPrice4","AskSize4","BidPrice4","BidSize4",...
                       "AskPrice5","AskSize5","BidPrice5","BidSize5"];

% Select only level 3 data.
TimeVariable = "Time";
DSMSG.SelectedVariableNames = TimeVariable;

LOB3Variables = ["AskPrice1","AskSize1","BidPrice1","BidSize1",...
                 "AskPrice2","AskSize2","BidPrice2","BidSize2",...
                 "AskPrice3","AskSize3","BidPrice3","BidSize3"];
DSLOB.SelectedVariableNames = LOB3Variables;
                               
DS = combine(DSMSG,DSLOB);     
%mapreducer(0)            % Only evaluated when excuted
DT = tall(DS); 
DTPreview = DT(:,1:5);
DT.Time = seconds(DT.Time); % Cast time as a duration from midnight.
DTT = table2timetable(DT);
DTTPreview = DTT(:,1:4)
%%
timeBase = DTT.Time;
MidPrice = (DTT.BidPrice1 + DTT.AskPrice1)/2;  % This is the midpoint at the ask-bid spread.

% LOB level 3 imbalance index:

lambda  = 0.5; % Hyperparameter
weights = exp(-(lambda)*[0 1 2]);
VAsk = weights(1)*DTT.AskSize1 + weights(2)*DTT.AskSize2 + weights(3)*DTT.AskSize3;
VBid = weights(1)*DTT.BidSize1 + weights(2)*DTT.BidSize2 + weights(3)*DTT.BidSize3;
ImbalanceIndex = (VBid-VAsk)./(VBid+VAsk);
